package EntryType;

public enum FuncType {
    VOID,
    INT,
    MAIN,
    NO,
}
