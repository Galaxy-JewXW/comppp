package Types;

public class Label implements Type {
    @Override
    public String toString() {
        return "label";
    }
}
