package Types;

public interface Type {
    String toString();
}
