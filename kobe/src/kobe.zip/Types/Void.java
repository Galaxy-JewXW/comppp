package Types;

public class Void implements Type {
    @Override
    public String toString() {
        return "void";
    }
}
