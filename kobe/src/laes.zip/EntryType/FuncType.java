package EntryType;

public enum FuncType {
    VoidFunc,
    IntFunc,
    MainFunc,
    NotFunc,
}
